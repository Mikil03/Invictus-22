//including express
const exp = require('express');


//db connection
const { createPool } = require('mysql');
const pool = createPool({
    host: "localhost",
    user: "root",
    password: "",
    database: "test"
})


//express app
const app = exp();

//register view engine
app.set('view engine','ejs');


//listen request
app.listen(3000);

//to include external files from public folder(to make files public to access)
app.use(exp.static('public'));

//to encode passed data
app.use(exp.urlencoded({extended: true}));


app.get('/',(req,res)=>{
    //to send index page
    res.render('login');//message can be dynamically accessed in index.ejs
})
app.get('/login',(req,res)=>{
    res.render('login');
})

//login auth
app.post('/login',(req,res)=>{
    const auth = req.body;
    var r = res;
    if(auth.no==undefined){
    pool.query("select * from user where mail=?",[auth.mail],(err,res,fields)=>{
            const verify = JSON.parse(JSON.stringify(res));
                if(err){
                    console.log(err);
                }
                else{
                    if(verify[0]==null)
                    {
                        console.log('user not registered');
                        r.redirect('/login?error=' + encodeURIComponent('UNR'));
                    }
                    else if(auth.pass==verify[0].pass)
                    {
                        console.log('successfull');
                        r.redirect('/success');
                    }
                    else{
                        console.log('incorrect password');
                        r.redirect('/login?error=' + encodeURIComponent('IP'));
                    }
                }
            });
    }
    else{
        pool.query("select mail from user where mail=?",[auth.mail],(err,res,field)=>{
            const check = JSON.parse(JSON.stringify(res));
            if(err){
                return console.log(err);
            }
            if(check[0]==null){
                pool.query("insert into user values(?,?,?,?)",[auth.name,auth.mail,auth.pass,auth.no],(err,res,fields)=>{
                    if(err){
                        return console.log(err);
                    }
                    console.log('insert successful');
                    r.redirect('/success');
                    return console.log(res);
                })
            }
            r.redirect('/login?error=' + encodeURIComponent('AE'));
        })
    }
})


//insert value in db
// app.post('/contact',(req,res)=>{
//     //const blog = new Blog(req.body);
//     const data = req.body;
//     pool.query("insert into data values(?,?,?,?)",[data.name,data.no,data.mail,data.message],(err,res,fields)=>{
//         if(err){
//             return console.log(err);
//         }
//         return console.log(res);
//     })
//     res.redirect('/contact');
//     //console.log(req.body);
// })
